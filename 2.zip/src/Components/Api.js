export default class Api {
  constructor(options) {
    this.baseUrl = options.baseUrl;
    this.headers = options.headers;
  }

getUserInform() {
  return fetch(`${this.baseUrl}/users/me`, {
      method: 'GET',
      headers: this.headers,
    })
    .then(res => {
      if (res.ok) {
        return res.json();
      } else {
        return Promise.reject(`Ошибка: ${res.status}`);
      }
    });
}

getCards() {
  return fetch(`${this.baseUrl}/cards`, {
    method: 'GET',
    headers: this.headers,
  })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });

}

updateProfileInfo(name, about) {
  return fetch(`${this.baseUrl}/users/me`, {
    method: 'PATCH',
    headers: this.headers,
    body: JSON.stringify({
      name: name,
      about: about
    })
  })
  .then(res => {
    if (res.ok) {
      return res.json();
    } 
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
  });

}

/* updateInfo(name, about) {
  return fetch(`${this._url}/users/me`, {
      method: 'PATCH',
      headers: this._headers,
      body: JSON.stringify({
        name: name,
        about: about
      })
    })
    .then(res => {
      if (res.ok) {
        return res.json();
      }
      return Promise.reject(`Ошибка: ${res.status}`);
    });
} */


createNewCard(name, link) {
  return fetch(`${this.baseUrl}/cards`, {
    method: 'POST',
    headers: this.headers,
    body: JSON.stringify({
      name: name,
      link: link
    })
  })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });
}

deleteCard(id) {
  return fetch(`${this.baseUrl}/cards/${id}`, {
    method: 'DELETE',
    headers: this.headers,
   })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });
}

addLike(card) {
  return fetch(`${this.baseUrl}/cards/likes/${card.id}`, {
    method: 'PUT',
    headers: this.headers,
   })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });
}  

deleteLike(card) {
  return fetch(`${this.baseUrl}/cards/likes/${card.id}`, {
    method: 'DELETE',
    headers: this.headers,
   })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });
}

updateAvatar() {
  return fetch(`${this.baseUrl}users/me/avatar`, {
    method: 'PATCH',
    headers: this.headers,
   })
  .then(res => {
    if (res.ok) {
      return res.json();
    } else {
      return Promise.reject(`Ошибка: ${res.status}`); //прописать текст ошибки
    }
  });
}
  // проверка запроса json
  //загрузка аватара
  //загрузка json карточек
  //ред. профиля
  //новая карточка
  //лайки кол-во
  //удаление карточки
  //удаление и постановка лайка
  //аватар пользователя
}