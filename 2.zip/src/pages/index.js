//import './index.css'; 
import Card from "../Components/Card.js";
import FormValidator from "../Components/FormValidator.js";
import Section from "../Components/Section.js";
import { PopupWithImage } from "../Components/PopupWithImage.js";
import PopupWithForm from "../Components/PopupWithForm.js";
import UserInfo from "../Components/UserInfo.js";
import {
  
  //profileName,
  //profileProfession,
  profileEditButton,
  popupEdit,
  popupInputName,
  popupInputProfession,
  buttonAddPlace,
  cardList,
  popupAddPlace,
  popupImage,
  templateCards,
  settingsValidation,
  buttonEditAvatar,
  popupEditAvatar,
  profileImage,
  profileInfo ////////////

} from "../utils/Constants.js";

import Api from '../Components/Api.js';

const api = new Api({
  baseUrl: 'https://mesto.nomoreparties.co/v1/cohort-16',
  headers: {
    authorization: '998fe87c-1205-4216-8ac1-5bc50516f491',
    'Content-Type': 'application/json'
  }
});

const formEditValidator = new FormValidator(settingsValidation, popupEdit);
const formCardValidator = new FormValidator(settingsValidation, popupAddPlace);
const formAvatarValidator = new FormValidator(settingsValidation, popupEditAvatar);


const userInfo = new UserInfo(profileInfo,
  profileImage
);

Promise.all([api.getUserInform(), api.getCards()]) //загрузка данных профиля
  .then(([user, cards]) => {
    userInfo.setUserInfo(user);
    defaultCardList.renderItems(cards, user._id);
  })
  .catch((err) => {
    console.log(err);
  });


  const profileForm = new PopupWithForm({ //отправляем информацию, введенную пользоавателем на сервер
    submit: () => {
     // loading(true, popupEdit, 'Сохранить', 'Сохранение...');
      api.updateProfileInfo(popupInputName.value, popupInputProfession.value)
        .then((result) => {
          userInfo.setUserInfo(result);
          profileForm.close();
        })
        .catch((err) => {
          console.log(err); // выведем ошибку в консоль
        })
        //.finally(() => {
          //loading(false, popupProfile, 'Сохранить', 'Сохранение...');
       // });
    }
  }, popupEdit);

  /*
const popupProfileForm = new PopupWithForm(
  { submit: (item) => userInfo.setUserInfo(item) },
  popupEdit
); */


const openProfile = () => {
  const infoAuthor = userInfo.getUserInfo();
  popupInputName.value = infoAuthor.name;
  popupInputProfession.value = infoAuthor.about; 
  formEditValidator.checkOpenedPopup();
  formEditValidator.enableValidation();
  profileForm.open();  

}

profileEditButton.addEventListener("click", openProfile);

const popupWithImage = new PopupWithImage(popupImage);
let valueCard;
const writeValueCard = (object, className) => { //запись значений в текущую карточк
  valueCard = {
    object: object,
    class: className
  };
};

const addLike = (object) => { //добавление лайка
  api.addLike(object)
    .then((result) => {
      valueCard.class.cardLike(result.likes.length);
    })
    .catch((err) => {
      console.log(err);
    });
};

const deleteLike = (object) => { //удаление лайка
  api.deleteLike(object)
    .then((result) => {
      valueCard.class.cardLike(result.likes.length);
    })
    .catch((err) => {
      console.log(err);
    });
}

const createCard = (item, userId, position) => { //создание карточки и добавление в разметку
  const card = new Card({
    data: item,
    handleCardClick: () => {
      popupWithImage.open(item);
    },
    handleCardLike: (cardObject) => {
      if (cardObject.like) {
        deleteLike(cardObject);
      } else {
        addLike(cardObject);
      }
      writeValueCard(item, card);
    },
    handleCardDelete: () => {
      deleteCardConfirm.open();
      writeValueCard(item, card);
    }
  }, templateCards, userId);
  const cardElement = card.generateCard();
  addCards(cardElement, position);
};


/*const getNewCard = (item, userId) => {
  const card = new Card(
    {
      data: item,
      handleCardClick: () => {
        popupWithImage.open(item);
      },
    },
    templateCards, 
    userId
  );
  return card.generateCard();
};*/

const defaultCardList = new Section({ //класс для добавления начальных карточек
  renderer: (item, userId) => {
    createCard(item, userId);
  }
}, cardList);



/* const defaultArrPictures = new Section({ //класс для добавления начальных карточек
  renderer: (item, userId) => {
    getNewCard(item, userId);
  }
}, cardList); */

const addCards = (card, position) => { //добавление карточки в DOM
  if (position === 'prepend') {
    defaultCardList.addItemPrepend(card);
  } else {
    defaultCardList.addItemAppend(card);
  }
};


const cardForm = new PopupWithForm({
  formSubmit: (item) => {
    //loading(true, popupAddPlace, 'Создать', 'Создание...');
    api.createNewCard(item.name, item.link)
      .then((result) => {
        createCard(result, result.owner._id, prepend);
        cardForm.close();
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
      //  loading(false, popupAddPlace, 'Создать', 'Создание...');
      });
  }
}, popupAddPlace);


/*const popupPlaces = new PopupWithForm(
  {
    submit: (item) => {
      defaultCardList.addItem(getNewCard(item));
    },
  },
  popupAddPlace
);*/

const openPlaceForm = () => {
  formCardValidator.checkOpenedPopup();
  formCardValidator.enableValidation();
  cardForm.open();
};

const popupAvatar = new PopupWithForm(  //попап редактирования аватара
  {
    submit: () => {}
  },
  popupEditAvatar
);

const openAvatarForm = () => { //функция открытия аватара
  formAvatarValidator.checkOpenedPopup();
  formAvatarValidator.enableValidation();
  popupAvatar.open();
}

//defaultArrPictures.renderItems(initialCards);
buttonAddPlace.addEventListener('click', openPlaceForm); 
buttonEditAvatar.addEventListener('click', openAvatarForm); //слушатель открытия аватара