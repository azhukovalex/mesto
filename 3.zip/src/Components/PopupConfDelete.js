import Popup from './Popup.js'


export class PopupConfDelete extends Popup {
  constructor({ submit }, popupElement) {
    super(popupElement);
    this._submit = submit;
  }

  open() {

  }

  setEventListeners() {
    
  }


}